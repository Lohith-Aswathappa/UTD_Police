const rp = require('request-promise');

const diningUrl = process.env.DININGURL;
const foodTruckUrl = process.env.FOODTRUCKURL;
const foodtruckNameUrl = process.env.FOODTRUCKNAMEURL;

const token = process.env.DININGTOKEN;

const diningAPI = {};

diningAPI.getDiningData = function () {

    var options = {
        method: 'POST',
        uri: diningUrl,
        formData: {
            authtoken: token,
        },
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options)
}

diningAPI.getFoodtruckData = function () {

    var options = {
        method: 'POST',
        uri: foodTruckUrl,
        formData: {
            authtoken: token,
        },
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options)
}

diningAPI.getFoodtruckNameData = function () {

    var options = {
        method: 'POST',
        uri: foodtruckNameUrl,
        formData: {
            authtoken: token,
        },
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options)
}

module.exports = diningAPI;