const rp = require('request-promise');

const parkingUrl = "https://www.utdallas.edu/oit/mobileapps/UTDallas/ws/7/parkingquery.php";
const token = "891e0da5d48bc1217fcd00a942569a60";

const parkingAPI = {};

parkingAPI.getParkingData = function (garageName, permitName) {

    var options = {
        method: 'POST',
        uri: parkingUrl,
        formData: {
            authtoken: token,
            garage: garageName,
            permit: permitName
        },
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options)
}

module.exports = parkingAPI;