const rp = require('request-promise');

const status_list_Url = process.env.ZABBIXLIST;

const status_ext_list_Url = process.env.ZABBIXEXTLIST;

const zabbixAPI = {};

zabbixAPI.getStatusList = function () {

    var options = {
        method: 'GET',
        uri: status_list_Url,
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options);
}

zabbixAPI.getExtStatusList = function () {

    var options = {
        method: 'GET',
        uri: status_ext_list_Url,
        json: true // Automatically stringifies the body to JSON
    };

    return rp(options)
}

module.exports = zabbixAPI;