const Alexa = require('ask-sdk-core');

const parkingAPI = require('../modules/parking-api.js');

garageName = "PS1"
permitName = "Gold"

console.log("world")

async function parking(){
        parkingAPI.getParkingData(garageName, permitName).then(function (value) {
            let availablepositions = value[0].Space;
            let dict = {};
            let speechText = ""
            availablepositions.forEach(element => {
                if(element.ParkingOption == "Gold"){
                    dict["gold"] = element.Available;
                }
                else if(element.ParkingOption == "Green"){
                    dict["green"] = element.Available;
                }
                else if(element.ParkingOption == "Orange"){
                    dict["orange"] = element.Available;
                }
                else if(element.ParkingOption == "Pay By Space"){
                    dict["pay_by_space"] = element.Available;
                }
                else if(element.ParkingOption == "Purple"){
                    dict["purple"] = element.Available;
                }
            })

            speechText = "There are";
            for(var key in dict){
                speechText += ` ${dict[key]} ${key} `
            }

            speechText += ` spots available in parking structure ${garageName}`;

            console.log(speechText)
            
        }, function (err) {
         console.log("error")
    });

}

parking().then();

        
        