const Alexa = require('ask-sdk-core');
const moment = require('moment-timezone');

const diningAPI = require('../../modules/dining-api.js');
const Utils = require('../../utils/utils.js');

Set.prototype.addItems = function(array) {
    for(var item of array){
        this.add(item)
    }
}

const DINING_LocationOpenCloseTimeIntentHanlder = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'DINING_LocationOpenCloseTimeIntent';
    },
    async handle(handlerInput) {

        let speechText = process.env.ER_MESSAGE;

        let slotValues = Utils.getSlotValues(handlerInput.requestEnvelope.request.intent.slots);
        let requestedRestaurantName = slotValues.Restaurant.resolved;

        let openClose = handlerInput.requestEnvelope.request.intent.slots.OpenClose.value;
        let day = handlerInput.requestEnvelope.request.intent.slots.day.value;
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;

        let daytime = "";

        let setfoodtruckID = "";
        let setfoodtruckName = "";

        let restaurantFoundFlag = 0;

        if(!Utils.isEmptyObject(day)){
            if(!Utils.isEmptyObject(time)){
                daytime = moment.tz(day +" "+time, 'America/Chicago');
            }
            else if(Utils.isEmptyObject(time)){
                daytime = moment.tz(day +" "+"03:00", 'America/Chicago');
            }
        }
        else if(Utils.isEmptyObject(day)){
            if(!Utils.isEmptyObject(time)){
                let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
                daytime = moment.tz(cur_Date +" "+time, 'America/Chicago');
            }
            else{
                let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
                daytime = moment.tz(cur_Date+" "+"03:00", 'America/Chicago');
            }
        }
        
        console.log("daytime: ", daytime)

        await diningAPI.getDiningData().then(function (value) {

            value.dining.forEach(function (location) {
                if (requestedRestaurantName.toUpperCase() == location.Name.toUpperCase()) {
                    restaurantFoundFlag = 1;
                    if(Utils.isEmptyObject(location.FoodTruckID)){
                        speechText = getOpenOrCloseTimeResponse(location, openClose.toUpperCase(), daytime);
                    }
                    else{
                        setfoodtruckID = location.FoodTruckID;
                        setfoodtruckName = location.Name;
                    }
                }
            });

        }, function (error) {
            speechText = process.env.ERROR_MESSAGE;
        });

        if(!Utils.isEmptyObject(setfoodtruckID)){
            await diningAPI.getFoodtruckData().then(function (value) {

                value.foodtruck.forEach(function (location) {
                    if (setfoodtruckID.toUpperCase() == location.FoodTruckID.toUpperCase()) {
                        speechText = getOpenOrCloseTimeResponseFoodTruck(location, setfoodtruckName, openClose.toUpperCase(), daytime);
                    }
                });
    
            }, function (error) {
                speechText = process.env.ERROR_MESSAGE;
            });
        }

        if(restaurantFoundFlag == 0){
            speechText = `I am sorry, ${requestedRestaurantName} is not on campus. You can ask more questions on dining and parking or you can say stop to exit.`
        }
        speechText = Utils.correctResponseForSSML(speechText);
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.lastSpeech = speechText;
        console.log("attributes: ", sessionAttributes.lastSpeech);
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

function getOpenOrCloseTimeResponseFoodTruck(location, foodtruckname, openClose, daytime){
    let responseText = `Sorry, ${foodtruckname} is not open.`

    let outputTimeFormat = 'hh:mm A';
    let timeformat = 'HH:mm';
    let daytimeDate = daytime.format('YYYY-MM-DD');
    let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
    //---
    let startTime = moment('11:00', timeformat);
    let closeTime = moment('14:00', timeformat);
    let cur_time =  moment.tz('America/Chicago');
    let temptime = daytime.format(timeformat);
    let time = moment(temptime, timeformat);
    //---
    let dow = daytime.weekday();

    if(!Utils.isEmptyObject(dow) && !(dow  > 0 && dow <= 5)){
        responseText = "Food trucks are open from monday to friday and closed on saturday and sunday."
    }
    else if(daytimeDate == location.OpenDate){
        if(time.isBefore(startTime, null, "[]")){
            responseText = `${foodtruckname} will open at eleven A M and closes at two P M ${Utils.interpretDay(daytimeDate)}.`
        }
        else if(time.isBetween(startTime, closeTime, null, "[]")){
            responseText = `${foodtruckname} is open at ${time.format(outputTimeFormat)} and closes at two P M ${Utils.interpretDay(daytimeDate)}.`
        }
        else if(time.isAfter(closeTime, null, "[]")){
            if(cur_time.isAfter(closeTime, null, "[]")){
                responseText = `${foodtruckname} closed at two P M ${Utils.interpretDay(daytimeDate)}.`
            }
            else{
                responseText = `${foodtruckname} closes at two P M ${Utils.interpretDay(daytimeDate)}.`
            }
        }
    }
    return responseText;
}

function getOpenOrCloseTimeResponse(location, OpenClose, daytime) {

    let locationName = location.Name;

    let responseText = `Sorry, ${locationName} is not open ${Utils.interpretDay(daytime)}.`
 
    let dow = daytime.weekday();

    let outputTimeFormat = 'hh:mm A';

    var openingTime = "";
    var closingTime = "";
    var format = 'HH:mm:ss';
    //---
    var midnight = moment('24:00:00', format);
    //---
    var extHoursRestaurantCloseFlag = false;
   
    var tempOpenTime = "";
    var tempCloseTime = "";

    location.Hours.forEach(function (hoursObject) {
        // Check if same day
        if(dow >= Utils.convertphpdowtojsdow(hoursObject.Begin_DOW) && dow <= Utils.convertphpdowtojsdow(hoursObject.End_DOW)) {
            openingTime = moment.tz(hoursObject.Begin_Time, format, 'America/Chicago');
            closingTime = moment.tz(hoursObject.End_Time, format, 'America/Chicago');
        }
    });

    location.ExtHours.forEach(function (extHoursObject) {
        let begin_Date = extHoursObject.Begin_Date;
        let end_Date = extHoursObject.End_Date;
        //---
        let cur_Date = moment(daytime).format('YYYY-MM-DD');
        //---

        if(cur_Date >= begin_Date && cur_Date <= end_Date){
            //if hours object is empty, restaurant is closed
            if(Utils.isEmptyObject(extHoursObject.Hours)){
                extHoursRestaurantCloseFlag = true;
            }
            else{
                console.log("extHoursRestaurantCloseFlag setting to false again")
                extHoursRestaurantCloseFlag = false;
                extHoursObject.Hours.forEach(function(HoursObjInExtHoursObj){
                    if(dow >= Utils.convertphpdowtojsdow(HoursObjInExtHoursObj.Begin_DOW) && dow <= Utils.convertphpdowtojsdow(HoursObjInExtHoursObj.End_DOW)){
                        //---
                        let tempChangeFormat = moment(daytime).format("HH:mm:ss");
                        //---

                        let tempInputTime = moment.tz(tempChangeFormat, format, 'America/Chicago');
                        let tempOpenTime = moment.tz(HoursObjInExtHoursObj.Begin_Time, format, 'America/Chicago');
                        let tempCloseTime = moment.tz(HoursObjInExtHoursObj.End_Time, format, 'America/Chicago');
                        if (tempInputTime >= tempOpenTime && tempInputTime<= tempCloseTime) {
                            tempOpenTime = moment.tz(HoursObjInExtHoursObj.Begin_Time, format, 'America/Chicago');
                            tempCloseTime = moment.tz(HoursObjInExtHoursObj.End_Time, format, 'America/Chicago');
                        }
                        openingTime = moment.tz(HoursObjInExtHoursObj.Begin_Time, format, 'America/Chicago');
                        closingTime = moment.tz(HoursObjInExtHoursObj.End_Time, format, 'America/Chicago');
                    }
                });
            }
        }
    });

    if(!Utils.isEmptyObject(tempOpenTime) && !Utils.isEmptyObject(tempCloseTime)){
        openingTime = tempOpenTime;
        closingTime = tempCloseTime;
    }

    if(location.Name == "The PUB @ UTD"){
        locationName = `The PUB at <say-as interpret-as=\"spell-out\">UTD</say-as>`
    }
    else{
        locationName = location.Name;
    }
 
    if(extHoursRestaurantCloseFlag){
        responseText = `Sorry, ${locationName} is not open ${Utils.interpretDay(daytime)}.`
    }

    else{
        //--
        let cur_datetime = moment().format('YYYY-MM-DD');
        let daytime_Date = moment(daytime).format('YYYY-MM-DD');
        let daytimeHours = moment(daytime).format("HH:mm");
        let openHours = moment(openingTime).format("HH:mm");
        let closeHours = moment(closingTime).format("HH:mm");
        daytimeTimeformat = moment(daytime_Date+" "+daytimeHours).format('YYYY-MM-DD HH:mm');
        openingTimeformat = moment(daytime_Date+" "+openHours).format('YYYY-MM-DD HH:mm');
        closingTimeformat = moment(daytime_Date+" "+closeHours).format('YYYY-MM-DD HH:mm');
        daytime = moment(daytimeTimeformat);
        openingTime = moment(openingTimeformat);
        closingTime = moment(closingTimeformat);
        //---
        if(OpenClose == 'OPEN'){ 
            if(daytime_Date > cur_datetime){
                responseText = `${locationName} will open at ${openingTime.format(outputTimeFormat)}`
                responseText += ` and closes at ${closingTime.format(outputTimeFormat)}.` //${Utils.interpretDay(daytime)}
            }
            else{
                if(daytime.isBefore(openingTime)) {
                    //console.log("time is before opening time");
                    responseText = `${locationName} is open at ${openingTime.format(outputTimeFormat)}`
                    responseText += ` and closes at ${closingTime.format(outputTimeFormat)}.` //${Utils.interpretDay(daytime)}.
                } 
                else{ 
                    //console.log("time is after opening time");
                    if(daytime.isAfter(closingTime) && closingTime.isBefore(midnight)){
                        //console.log("time is after opening time and after closing time");
                        let cur_time =  moment.tz('America/Chicago');
                        //console.log("cur_time: ", cur_time);
                        if(cur_time > closingTime){
                            responseText = `${locationName} closed at ${closingTime.format(outputTimeFormat)} ${Utils.interpretDay(daytime)}`
                        }
                        else{
                            responseText = `${locationName} closes at ${closingTime.format(outputTimeFormat)} ${Utils.interpretDay(daytime)}.`
                        }
                        
                    }
                    else{
                        //console.log("time is after opening time and before closing time");
                        responseText = `Yes, ${locationName} is open at ${daytime.format(outputTimeFormat)}`
                        responseText += ` and closes at ${closingTime.format(outputTimeFormat)}.` //${Utils.interpretDay(daytime)}.`
                    }
                }
            }
            responseText += ' Contact the store for holidays and weekend hours.';  
        }
        else{
            if (daytime.isAfter(closingTime) && closingTime.isBefore(midnight)) {
                responseText = `${locationName} closed at ${closingTime.format(outputTimeFormat)}.` //${Utils.interpretDay(daytime)}`
                responseText += ' Contact the store for holidays and weekend hours.';
            } 
            else {
                responseText = `${locationName} closes at ${closingTime.format(outputTimeFormat)}.` //${Utils.interpretDay(daytime)}`
                responseText += ' Contact the store for holidays and weekend hours.';
            }
        }
    }
    return responseText;
}

module.exports = DINING_LocationOpenCloseTimeIntentHanlder;