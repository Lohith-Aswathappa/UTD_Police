const Alexa = require('ask-sdk-core');
const diningAPI = require('../../modules/dining-api.js');
const Utils = require('../../utils/utils.js');

const DINING_OnCampusIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'DINING_OnCampusIntent';
    },
    async handle(handlerInput) {

        let speechText = process.env.ER_MESSAGE;
        let flag = 0;
        let slotValues = Utils.getSlotValues(handlerInput.requestEnvelope.request.intent.slots);
        let requestedRestaurantName = slotValues.Restaurant.resolved;
        let userquery = handlerInput.requestEnvelope.request.intent.slots.Restaurant.value;

        await diningAPI.getDiningData().then(function (value) {

            value.dining.forEach(function (location) {
                if (location.Name.toUpperCase() == requestedRestaurantName.toUpperCase()) {
                    flag = 1;
                }
            });
            
            if(requestedRestaurantName.toUpperCase() == "THE PUB @ UTD"){
                requestedRestaurantName = "The PUB at U T D";
                userquery = "The PUB at U T D";
            }
            speechText = flag == 1 ? `Yes, ${requestedRestaurantName} is on campus` : `I am sorry, ${requestedRestaurantName} is not on campus`;

        }, function (error) {
            speechText = process.env.ERROR_MESSAGE;
        });
        speechText = Utils.correctResponseForSSML(speechText);
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.lastSpeech = speechText;
        console.log("attributes: ", sessionAttributes.lastSpeech);
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        speechText += ". you can ask more questions on dining and parking or you can say stop to exit";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = DINING_OnCampusIntentHandler;