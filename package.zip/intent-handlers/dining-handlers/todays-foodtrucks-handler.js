const Alexa = require('ask-sdk-core');
const moment = require('moment');
const diningAPI = require('../../modules/dining-api.js');
const Utils = require('../../utils/utils.js');

const DINING_TodaysFoodtruckIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'DINING_TodaysFoodtruckIntent';
    },
    async handle(handlerInput) {

        let speechText = process.env.ER_MESSAGE;

        let day = handlerInput.requestEnvelope.request.intent.slots.day.value;
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;
        let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
        let dow = "";
        let openLocations = [];
        
        if(!Utils.isEmptyObject(day)){
            dow = moment(day).weekday();
        }
        let timeformat = 'HH:mm';
        let startTime = moment('11:00', timeformat);
        let closeTime = moment('14:00', timeformat);
        if(!Utils.isEmptyObject(time)){
            time = moment(time, timeformat);
        }
        
        if(!Utils.isEmptyObject(dow) && !(dow  > 0 && dow <= 5)){
            speechText = "I am sorry, Food trucks are open only from monday to friday."
        }
        else if(!Utils.isEmptyObject(time) && !time.isBetween(startTime, closeTime, null, "[]")){
            speechText = "I am sorry, Food trucks are only open from eleven A M to two P M"
        }
        else{
            await diningAPI.getFoodtruckNameData().then(function (value) {

                let today = "";
                if(Utils.isEmptyObject(day)){
                    today = moment().tz("America/Chicago").format('YYYY-MM-DD');
                }
                else{
                    today = day;
                }
                //
                //  Filter out all objects with dates that are not today
                //
                let openToday = value.foodtruck.filter(function (item) {
                    let itemDay = moment(item.OpenDate, "YYYY-MM-DD");
                    //return itemDay.isSame(today, 'day');
                    return itemDay.isSame(today, 'YYYY-MM-DD');
                });
    
                //
                //  Build speech Text
                //
                if (openToday.length == 0) {
                    speechText = `Sorry, there are no foodtrucks on campus ${Utils.interpretDay(today)}.`;
                } 
                else if(openToday.length == 1){
                    speechText = openToday[0].Name + ` is open on campus ${Utils.interpretDay(today)}.`;
                    speechText += '. Contact the store for holidays and weekend hours';
                }
                else {
                        speechText = `The foodtrucks on campus ${Utils.interpretDay(today)} are `;
                    openToday.forEach(function (val, key, arr) {
                        if (Object.is(arr.length - 1, key)) {
                            speechText += 'and ' + val.Name + '.';
                        } else {
                            speechText += val.Name + ', ';
                        }
                    });
                    speechText += '. Contact the store for holidays and weekend hours';
                }
    
            }, function (error) {
                speechText = process.env.ERROR_MESSAGE;
            }); 
        
        }
        // Fix any issues with reponse statement not conforming to SSML standards (e.g. "&" causes crash ¯\_(ツ)_/¯)
        speechText = Utils.correctResponseForSSML(speechText);
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.lastSpeech = speechText;
        console.log("attributes: ", sessionAttributes.lastSpeech);
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Today\'s Foodtrucks', speechText)
            .getResponse();
    },
};

module.exports = DINING_TodaysFoodtruckIntentHandler;