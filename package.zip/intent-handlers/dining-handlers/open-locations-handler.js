const Alexa = require('ask-sdk-core');
const moment = require('moment-timezone');

const diningAPI = require('../../modules/dining-api.js');
const Utils = require('../../utils/utils.js');

Set.prototype.addItems = function(array) {
    for(var item of array){
        this.add(item)
    }
}

const DINING_OpenLocationsIntentHanlder = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'DINING_OpenLocationsIntent';
    },
    async handle(handlerInput) {

        let speechText = process.env.ER_MESSAGE;

        let day = handlerInput.requestEnvelope.request.intent.slots.day.value;
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;

        let outputTimeFormat = 'hh:mm A';

        let today = "";

        if(!Utils.isEmptyObject(day)){
            if(!Utils.isEmptyObject(time)){
                today = moment.tz(day +" "+time, 'America/Chicago');
                console.log("today1: ", today);
            }
            else if(Utils.isEmptyObject(time)){
                today = moment.tz(day +" "+"11:00", 'America/Chicago');
            }
        }
        else if(Utils.isEmptyObject(day)){
            if(!Utils.isEmptyObject(time)){
                let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
                today = moment.tz(cur_Date +" "+time, 'America/Chicago');
                console.log("today2: ", today);
            }
            else{
                let cur_Date = moment().tz("America/Chicago").format('YYYY-MM-DD');
                today = moment.tz(cur_Date+" "+"11:00", 'America/Chicago');
            }
        }

        let displaytime = moment(time, 'HH:mm');

        let interpretedDay = Utils.interpretDay(today);
        
        let openLocations = [];

        await diningAPI.getDiningData().then(function (value) {

            value.dining.forEach(function (location) {
                if (isLocationOpen(location, today)) {
                    openLocations.push(location.Name);
                }
            });

            if (openLocations.length == 0) {
                speechText = `Sorry, there are no restaurants that are open ${interpretedDay} at ${displaytime.format(outputTimeFormat)}.`;
            } 
            else if(openLocations.length == 1){
                speechText = openLocations[0] + ` is open ${interpretedDay} at ${displaytime.format(outputTimeFormat)}`;
            }
            else {
                speechText = `The restaurants that are open ${interpretedDay} at ${displaytime.format(outputTimeFormat)} are `;
                openLocations.forEach(function (val, key, arr) {
                    if (Object.is(arr.length - 1, key)) {
                        if(val == "The PUB @ UTD"){
                            val = `The PUB at <say-as interpret-as=\"spell-out\">UTD</say-as>`
                        }
                        speechText += 'and ' + val + '.';
                    } else {
                        if(val == "The PUB @ UTD"){
                            val = `The PUB at <say-as interpret-as=\"spell-out\">UTD</say-as>`
                        }
                        speechText += val + ', ';
                    }
                });
                speechText += '. Contact the store for holidays and weekend hours';
            }
        }, function (error) {
            speechText = process.env.ERROR_MESSAGE;
        });
        speechText = Utils.correctResponseForSSML(speechText);
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.lastSpeech = speechText;
        console.log("attributes: ", sessionAttributes.lastSpeech);
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

function isLocationOpen(location, today) {

    let open = false;
    let dow = "";

    dow = today.weekday();

    if(!Utils.isEmptyObject(location.FoodTruckID))
    {
        return false;
    }
    location.Hours.forEach(function (hoursObject) {

        // Check if same day
        if (dow >= hoursObject.Begin_DOW && dow <= hoursObject.End_DOW) {
            
            let format = 'HH:mm:ss';

            let openingTime = moment.tz(hoursObject.Begin_Time, format, 'America/Chicago');
            let closingTime = moment.tz(hoursObject.End_Time, format, 'America/Chicago');
            let todayTime = moment.tz(today.format("HH:mm:ss"), format, 'America/Chicago');
            // Check if current time is between these times
            if (todayTime.isBetween(openingTime, closingTime, null, '[]')) {
                open = true;
            }
        }
    });

    //check for extended hours
    var overrideOpen = false;

    location.ExtHours.forEach(function (ExtHoursObject){

        //Check if currentDate lies between beginDate and EndDate
        let begin_Date = ExtHoursObject.Begin_Date;
        let end_Date = ExtHoursObject.End_Date;
        let cur_Date = new Date(today).toISOString().slice(0,10); 

        if(cur_Date >= begin_Date && cur_Date <= end_Date){
            //check if hours object is empty
            if(Utils.isEmptyObject(ExtHoursObject.Hours)){
                open = false;
            }
            else{
                ExtHoursObject.Hours.forEach(function(HoursObjInExtHoursObj){
                    //check if dow lies between begin and end dow
                       if (dow >= Utils.convertphpdowtojsdow(HoursObjInExtHoursObj.Begin_DOW) && dow <= Utils.convertphpdowtojsdow(HoursObjInExtHoursObj.End_DOW)){
                        let extHrs_format = 'HH:mm:ss';
                        let extHrs_openingTime = moment.tz(HoursObjInExtHoursObj.Begin_Time, extHrs_format, 'America/Chicago');
                        let extHrs_closingTime = moment.tz(HoursObjInExtHoursObj.End_Time, extHrs_format, 'America/Chicago');
                        let exttodayTime = moment.tz(today.format("HH:mm:ss"), extHrs_format, 'America/Chicago');
                        //check if time lies between open and close time
                        if (exttodayTime.isBetween(extHrs_openingTime, extHrs_closingTime, null, '[]')) {
                            open = true;
                            overrideOpen = true;
                        }
                        //if current time is not between open and close time, then restaurant is closed
                        else{
                            open = false;
                        }
                    }
                });
            }
        }
    });
    return open || overrideOpen;
}

module.exports = DINING_OpenLocationsIntentHanlder;