const Alexa = require('ask-sdk-core');
const Constants = require('../../utils/Constants.js');
const Utils = require('../../utils/utils.js');

const FACTS_NewFactIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'FACTS_NewFactIntent';
    },
    async handle(handlerInput) {

        let speechText = "";

        let newFact = getRandomFact(handlerInput);

        speechText = 'Here\'s your fact, ' + newFact;
        let reprompt = "";
        speechText = Utils.correctResponseForSSML(speechText);
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(reprompt)
            .withSimpleCard('UTD Facts', speechText)
            .getResponse();
    },
};

/*
*   Getting random fact
*/

function getRandomFact(handlerInput) {

    let providedFacts = getProvidedFacts(handlerInput);

    // Create list of indexes that correspond to the facts array
    let indexArr = Constants.FACTS.map(function (val, index) {
        return index
    })

    // Check if usedIndexes array is same length of all index array, then just return any random one. 
    if (providedFacts.length == indexArr.length) {
        let index = Math.floor(Math.random() * indexArr.length);
        return Constants.FACTS[index];
    }

    // Filter out all used indexes
    let remainingIndexes = indexArr.filter(function (val, index) {
        return !providedFacts.includes(val);
    })

    // Randomly pick from the remaining indexes
    let index = Math.floor(Math.random() * remainingIndexes.length);


    // Added now used index to the list of used indexes
    addToProvidedFacts(handlerInput, remainingIndexes[index]);

    return Constants.FACTS[remainingIndexes[index]];
}

/*
*   Session Attributes
*/

function addToProvidedFacts(handlerInput, index) {

    const attributesManager = handlerInput.attributesManager;
    const sessionAttributes = attributesManager.getSessionAttributes();

    const providedHintsKey = 'providedFacts';

    if (sessionAttributes[providedHintsKey]) {
        sessionAttributes[providedHintsKey].push(index);
    } else {
        sessionAttributes[providedHintsKey] = [index];
    }

    attributesManager.setSessionAttributes(sessionAttributes);
}

function getProvidedFacts(handlerInput) {
    const attributesManager = handlerInput.attributesManager;
    const sessionAttributes = attributesManager.getSessionAttributes();

    const providedHintsKey = 'providedFacts';

    if (sessionAttributes[providedHintsKey]) {
        return sessionAttributes[providedHintsKey];
    } else {
        return [];
    }
}

module.exports = FACTS_NewFactIntentHandler;