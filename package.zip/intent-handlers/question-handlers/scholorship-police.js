const Alexa = require('ask-sdk-core');

const QUESTION_ScholorshipPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'scholarship_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Applications are available at the UT Dallas Financial Aid Office located on the first floor of the Student Services Building S S B";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ScholorshipPolice;