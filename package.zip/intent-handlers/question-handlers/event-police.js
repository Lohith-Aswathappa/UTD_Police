//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_EventPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'event_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Fill out the Event Registration Form found at h t t p s : double slash www dot u t dallas dot edu / police / event form dot h t m l. University departments and registered campus organizations can make requests for parking needs, unlocks, lockups, guards, and police officers to work their events.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_EventPolice;