const Alexa = require('ask-sdk-core');

const QUESTION_ReportEventHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'hack_report_event';
    },
    async handle(handlerInput) {

        let speechText = "";

        let name = handlerInput.requestEnvelope.request.intent.slots.name.value;
        let phnumber = handlerInput.requestEnvelope.request.intent.slots.phnumber.value;
        let place = handlerInput.requestEnvelope.request.intent.slots.place.value;
        let action = handlerInput.requestEnvelope.request.intent.slots.action.value;


        speechText += "Your incident has been successfully reported. The U T Dallas Police Department will get back to you soon. Thank you";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ReportEventHandler;