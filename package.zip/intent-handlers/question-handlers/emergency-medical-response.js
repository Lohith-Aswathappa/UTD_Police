//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_EmergencyMedicalResponse = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'emergency_medical_response';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "For any on campus medical emergency, call U T Dallas Police at 9 7 2 8 8 3 2 2 2 2. U E M R will respond first, and the city of Richardson's 9 1 1 service will be called if needed.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_EmergencyMedicalResponse;