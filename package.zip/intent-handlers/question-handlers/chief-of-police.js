//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_ChiefOfPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'chief_of_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Chief Zacharias has been the U T Dallas Police Chief since September 2009. You can find further information at the below link h t t p s : double slash www dot utdallas dot e d u / police / bio underscore zacharias dot h t m l";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ChiefOfPolice;