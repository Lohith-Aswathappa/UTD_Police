const Alexa = require('ask-sdk-core');

const QUESTION_SafeUtdallas = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'safe_utdallas';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "U T D gives high importance to student safety. It has a dedicated police department and corresponding helplines available 24 by 7 and are always ready to help students.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_SafeUtdallas;