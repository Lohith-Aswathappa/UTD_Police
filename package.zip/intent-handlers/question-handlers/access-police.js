//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_AccessPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'access_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "U T D Police has access to most buildings except U Rec, Arts and Technology center, Callier Dallas Engineering and Computer Science, E C S N, E C S S, E P P S Computer Labs, Office of Information Technology Computer Labs, Natural Science & Engineering, Research Lab, Bioengineering Science Building, N S E R L Vivarium, Residence Halls, Student Media , and Student Success Center. However, U T D Police is responsible for regularly auditing access lists, maintaining access records of all the Buildings ";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_AccessPolice;