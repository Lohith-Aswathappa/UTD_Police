const Alexa = require('ask-sdk-core');

const QUESTION_StudentPatrolPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'student_patrol_shift';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "The daily shift of Student Patrol is from 6 pm to 10 pm";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_StudentPatrolPolice;