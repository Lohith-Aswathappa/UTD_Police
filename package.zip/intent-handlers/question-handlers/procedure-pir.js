const Alexa = require('ask-sdk-core');

const QUESTION_ProcedurePIR = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'procedure_pir';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Submit the filled out Public Information Request Form available at h t t p s : double slash www dot utdallas dot e d u / e h s / r m / insurance / public hyphen information / via email to public information at u t dallas dot e d u, or via fax to 9 7 2 8 8 3 2 2 2 0, or via post to 800 West Campbell Road, AD 35, Richardson, TX 7 5 0 8 0 3 0 2 1.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ProcedurePIR;