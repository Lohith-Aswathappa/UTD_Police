const Alexa = require('ask-sdk-core');

const QUESTION_LostAndFoundHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'hack_lost_and_found';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Fill out the Lost and Found Inquiry form found at h t t p s : double slash www dot utdallas dot edu / police / lost and found dot h t m l, describing your lost item. Please be as detailed as possible when filling out the description of the item. Refrain from entering sensitive information such as drivers license numbers, Social Security Numbers, or Comet Card numbers. All lost Comet Card inquiries must be directed to the Comet Card Office in the Student Services Building Addition S S A. The Police Department will reach out to you once they come across a positive match.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_LostAndFoundHandler;