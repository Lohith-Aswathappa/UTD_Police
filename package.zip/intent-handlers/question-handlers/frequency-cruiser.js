//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_FrequencyCruiser = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'frequency_cruiser';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "The George Bush East bus which terminates at Cityline Bush Station runs every 30 min. The West buses run every 20 min. The bus schedule can be found at www dot dart dot org and both the schedule and live location of the bus can be seen in the U T D Mobile app.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_FrequencyCruiser;