const Alexa = require('ask-sdk-core');

const QUESTION_ReportAssault = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'report_assault';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "U T Dallas students cam report any assault incident to a campus security authority such as the University Police, Office of the Dean of Students, University residential life personnel, deans, directors, department heads, Student Health Services, the Womens Center, and the Counseling Center. If the assault occurred outside the U T Dallas campus, contact the local police department where the assault occurred. U T Dallas personnel will assist can contact the local police department upon request.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ReportAssault;