//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_EmploymentPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'employment_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "U T D police is recruiting individuals who seek a rewarding, demanding career through which they can make a positive impact on the community they serve. Complete and submit a resume based application by visiting The U T Dallas Human Resources job website.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_EmploymentPolice;