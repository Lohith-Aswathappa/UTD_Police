const Alexa = require('ask-sdk-core');

const QUESTION_PoliceStudentsHome = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'police_students_home';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Yes, Connect to the police department using the Emergency Call Phones present in multiple locations around the campus.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_PoliceStudentsHome;