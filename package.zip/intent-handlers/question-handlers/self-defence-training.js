const Alexa = require('ask-sdk-core');

const QUESTION_SelfDefenceTraining = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'self_defence_training';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "R A D Rape Aggression Defence Systems is a network of dedicated self defense instructors established in 19 89. The registration link can be found at the below link h t t p s : double slash www dot utdallas dot edu / police / rad dot h t m l";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_SelfDefenceTraining;