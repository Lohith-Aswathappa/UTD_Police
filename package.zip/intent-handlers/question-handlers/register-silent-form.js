const Alexa = require('ask-sdk-core');

const QUESTION_RegisterSilentForm = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'register_silent_form';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "DO NOT use Silent Witness to report crimes in progress. There may be a delay of a few days before an investigator is able to follow up on information provided. For crimes in progress or an incident requiring immediate police response, dial 9 1 1 or call U T D Police Communications at 9 7 2 8 8 3 2 2 2 2. To fill the silent witness form please access the below link h t t p s : double slash www dot utdallas dot edu / police / silent witness dot h t m l. Also remember it Is a violation of law to make a false report to a law enforcement agency and is punishable by fine up to 4000 dollars or 1 year in prison";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_RegisterSilentForm;