//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_LocationPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'location_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "The University Police Department is located at 800 West Campbell Road P D 11, Richardson, Texas 7 5 0 8 0";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_LocationPolice;