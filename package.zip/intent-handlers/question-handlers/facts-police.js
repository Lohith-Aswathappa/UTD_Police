//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_FactsPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'facts_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "The University of Texas at Dallas Police are committed to creating an environment in which teaching, research, community life and public service may flourish. The UT Dallas Police Department maintains an Interlocal Agreement with the City of Richardson for fire and EMS response. The UT Dallas Police is available 24 7 for our safety. UT Dallas police officers patrol the campus by car and foot. Uniformed police officers provide safety to students living in campus housing by monitoring resident's late-entry access, checking exterior doors and patrolling halls.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_FactsPolice;