//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_AccessCrimeLog = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'access_crime_log';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Daily crime logs can be found at h t t p s : double slash www dot u t dallas dot edu / police / public info dot h t m l for every month, December 2008 onwards";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_AccessCrimeLog;