//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_JuristrictionPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'juristriction_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "U T Dallas police officers are vested with all the powers, privileges, and immunities of peace officers, and may, in accordance with Chapter 14 of the Code of Criminal Procedure, arrest without a warrant any person who violates a law of the state and may enforce all traffic laws on streets and highways. The U T Dallas Police Department limits its reporting authority and jurisdiction to the main U T Dallas campus and contiguous streets and roads as well as The Callier Center Dallas; Center for Brain Health, Dallas and Center for Vital Longevity, Dallas.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_JuristrictionPolice;