//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_BenefitsStudentPatrol = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'benefits_student_patrol';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "some of the benefits are, On campus job, An understanding work environment regarding your academic priorities, Get started on your career in law enforcement or criminal justice, Sense of pride in serving your community as members of the U T Dallas Police Department, Develop contacts for future employment references";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_BenefitsStudentPatrol;