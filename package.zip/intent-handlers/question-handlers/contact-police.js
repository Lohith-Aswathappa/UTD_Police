//comment
const Alexa = require('ask-sdk-core');

const  QUESTION_ContactPolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'contact_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "In case of an emergency, call 9 1 1. Users can also call 2 2 2 2 or 9 7 2 8 8 3 2 2 2 2 for both emergency and non emergency situations. Emergency call phones called Blue Phones present in multiple places around the main campus and campus apartments connect callers to the U T Dallas 9 1 1 Center along with their location.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ContactPolice;