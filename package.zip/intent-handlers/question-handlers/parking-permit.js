const Alexa = require('ask-sdk-core');

const QUESTION_ParkingPermit = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'parking_permit';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Fill out the form to apply for a new parking permit found at h t t p s : double slash utdallas dot t 2 hosted dot com / Account / Portal and make the appropriate payment.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_ParkingPermit;