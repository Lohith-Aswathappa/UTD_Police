const Alexa = require('ask-sdk-core');

const QUESTION_StudentRepresentativePolice = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'student_representative_police';
    },
    async handle(handlerInput) {

        let speechText = "";
        speechText += "Yes, they are called Student Patrol Officers. They assist U T D Police and the community by serving as trained eyes and ears, conducting foot patrols on the campus, including the residential areas of the campus. Services include walking escorts, entry assists, and other support services roles not requiring a commissioned police officer. Student C S O s will identify and report suspicious activity and safety issues while conducting their patrols.";
        console.log(speechText);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Open Now', speechText)
            .getResponse();
    },
};

module.exports = QUESTION_StudentRepresentativePolice;