const Alexa = require('ask-sdk-core');

const AMAZON_ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`Error handled: ${error.message}`);

        let errorMessage = "Sorry, there was a problem retrieving the information you are looking for.";
        let reprompt = "Sorry, there was a problem retrieving the information you are looking for.";

        return handlerInput.responseBuilder
            .speak(errorMessage)
            .reprompt(reprompt)
            .withSimpleCard('Sorry ¯\_(ツ)_/¯', errorMessage)
            .getResponse();
    },
};

module.exports = AMAZON_ErrorHandler;