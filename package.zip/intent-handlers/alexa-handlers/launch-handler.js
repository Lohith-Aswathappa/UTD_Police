const Alexa = require('ask-sdk-core');

const AMAZON_LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speechText = "Welcome to U T D Police! Currently, you can ask questions about the Police Department or report an incidence. What can I help you with?";
        let reprompt = "Welcome to U T D Police! Currently, you can ask questions about the Police Department or report an incidence. What can I help you with?";
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.lastSpeech = speechText;
        console.log(sessionAttributes);
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(reprompt)
            .withSimpleCard("UTD Police", speechText)
            .getResponse();
    },
};

module.exports = AMAZON_LaunchRequestHandler; 